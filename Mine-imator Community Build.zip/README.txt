How to install:

1.) Extract the .zip to your desktop
2.) Move the extracted folder to "C:\Users\YOURNAME"
3.) Create a shortcut of the .exe file and move it to your desktop.